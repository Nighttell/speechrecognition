import os
import aiml
import pyttsx3

def aili(a):
    def get_alice():
        os.chdir('./botdata/alice')  # 首先配置的语料库地址
        alice = aiml.Kernel()
        alice.learn("startup.xml")  # 此处加载XML文件，即语料
        alice.respond('LOAD ALICE')
        return alice

    def spk(b):
        engine = pyttsx3.init()
        engine.setProperty("voice", "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_ZH-CN_HUIHUI_11.0")
        engine.say(b)
        engine.runAndWait()

    alice = get_alice()
    b = alice.respond(a)
    c=0;
    string = ":"
    for i in string:
        if i in b:
            c=1

    if c==1:
        os.system(b)
    else:
        spk(b)



    return b



