from PySide2.QtCore import QMutex
from PySide2.QtWidgets import QApplication, QMessageBox
from PySide2.QtUiTools import QUiLoader
import myapi
import speech
import luyin
import spkspeech
from threading import Thread
import huanxing
import alice
import pyttsx3
import luyin1

from aip import AipSpeech
from playsound import playsound

mutex = QMutex()
class Stats:

    def __init__(self):
        # 从文件中加载UI定义

        # 从 UI 定义中动态 创建一个相应的窗口对象
        # 注意：里面的控件对象也成为窗口对象的属性了
        # 比如 self.ui.button , self.ui.textEdit
        self.ui = QUiLoader().load('main.ui')

        self.ui.pushButton_5.clicked.connect(self.get_audio)
        self.ui.pushButton_4.clicked.connect(self.spk)
        self.ui.pushButton.clicked.connect(self.QA)
        thread3 = Thread(target=self.th3,)
        thread3.start()




    def get_audio(self):
        self.ui.textEdit_3.setPlainText('''正在录音！请说话！！！''')
        luyin.LY()


        self.ui.textEdit_3.setPlainText(myapi.realize())


    def spk(self):
        thread1 = Thread(target=self.th2,)
        thread1.start()
    def th2(self):

        engine = pyttsx3.init()
        engine.setProperty("voice", "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_ZH-CN_HUIHUI_11.0")
        engine.say(self.ui.textEdit_2.toPlainText())
        engine.runAndWait()#语音输出代码

    def th3(self):

        while True:
            print("3")


            if(huanxing.si()=="西娜"):

                self.ui.label.setText('''西娜听见啦！''')
                luyin1.LY()
                a=myapi.realize()
                self.ui.label_4.setText(a)
                b=alice.aili(a)
                self.ui.label_5.setText(b)





                self.ui.label.setText('''你还有想说的嘛？''')
                print("2")
                break

    def QA(self):
        with open('./botdata/alice/tuling.aiml', 'r',encoding='utf-8') as r:
            lines = r.readlines()
        with open('./botdata/alice/tuling.aiml', 'w',encoding='utf-8') as w:
            for l in lines:
                if '</aiml>' not in l:
                    w.write(l)

        with open('./botdata/alice/tuling.aiml', 'a',encoding='utf-8') as f:
            f.write('<category>\n<pattern>'+self.ui.textEdit_4.toPlainText()+"*"+'</pattern>\n<template>'+self.ui.textEdit_5.toPlainText()+'</template>\n</category>\n</aiml>')
            engine = pyttsx3.init()
            engine.setProperty("voice",
                               "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_ZH-CN_HUIHUI_11.0")
            engine.say("我学会啦 再试试问问我吧")
            engine.runAndWait()  # 语音输出代码










app = QApplication([])
stats = Stats()
stats.ui.show()
app.exec_()
