#import ffmpeg
from pydub import AudioSegment
from pydub.playback import play
#import aukit

start_time=0
end_time=10000  #10秒
sound = AudioSegment.from_file("en_outfile.wav", format='wav')

#语音增强
lounder_via_method = sound.apply_gain(+10)

#保存文件
def save():
    part = lounder_via_method[start_time:end_time]
    data_split_filename = 'save.wav'
    part.export(data_split_filename, format='wav')

#保存为mp3
def sav3():
    part = lounder_via_method[start_time:end_time]
    data_split_filename = 'save.mp3'
    part.export(data_split_filename, format='mp3')

#播放功能
def plays(sound):
    play(sound)

save()
