from aip import AipSpeech
from playsound import playsound
from pydub import AudioSegment
from pydub.playback import play


def sp(content_s):
    """ 你的 APPID AK SK """
    APP_ID = '25013414'
    API_KEY = 'A78F8aswrTceMOh5tT0ItMdj'
    SECRET_KEY = 'ZSUGYxvg0KbEC574Z8OkyjjeH3V2yVUR'

    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)



    result = client.synthesis(content_s, 'zh', 1, {
        'vol': 5,
        'spd': 3,
        'pit': 6,
        'per': 4,
    })

    #转女音并保存
    if not isinstance(result, dict):
        with open('./sound/au.mp3', 'wb') as f:
            f.write(result)
    #print(result['err_msg'])
    #playsound(r"D:\c++\pythonProject\auido.mp3")
    playsound("./sound/au.mp3")
    #播放